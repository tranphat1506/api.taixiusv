# install requirments lib
>> npm install
# run server Backend on port 3300
>> npm run dev

# run server frontend = Live Server
