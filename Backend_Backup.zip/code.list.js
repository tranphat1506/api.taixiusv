const ERROR_LIST_CODE = {
    MODEL_USER_01 : "User already exist!",
    VALUE_DETECTED_01 : "Null value or undefinded value!",
    VALUE_DETECTED_02 : "Null value or undefinded value!",
    VALUE_DETECTED_03 : "Null value or undefinded value!",
    VALUE_DETECTED_04 : "Null value or undefinded value!",
}